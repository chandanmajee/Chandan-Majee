const allowedUsers = ["@chandanmajee", "@neha123", "@raj_verma"];

function checkGift() {
  const input = document.getElementById("insta").value.trim();
  const giftBox = document.getElementById("gift-box");
  const inputArea = document.getElementById("input-area");

  if (allowedUsers.includes(input)) {
    inputArea.classList.add("hidden");
    giftBox.innerHTML = `
      <h2>🎁 Thank You for Wishing Me!</h2>
      <img src="https://i.ibb.co/R5mMYSG/Screenshot-2025-06-22-10-58-37-42-948cd9899890cbd5c2798760b2b95377.jpg" alt="Birthday Gift" style="max-width: 250px; border-radius: 12px;" />
      <p>Ye lo aapka gift – ek Dairy Milk 🍫 aur mere dil se Thank You 💖</p>
    `;
    launchConfetti();
  } else {
    giftBox.innerHTML = `
      <p style="font-size: 18px; color: #444;">
        😢 <strong>Oops!</strong> Tumne mujhe wish nahi kiya abhi tak 🥲.<br>
        🎉 Wish karne ke baad jab tumhe reply mil jayega, tab gift open kar paoge 😀
      </p>
    `;
  }
}

function launchConfetti() {
  const duration = 3 * 1000;
  const animationEnd = Date.now() + duration;
  const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };

  function randomInRange(min, max) {
    return Math.random() * (max - min) + min;
  }

  const interval = setInterval(function () {
    const timeLeft = animationEnd - Date.now();
    if (timeLeft <= 0) return clearInterval(interval);
    const particleCount = 50 * (timeLeft / duration);
    confetti({
      particleCount,
      origin: {
        x: randomInRange(0.1, 0.9),
        y: Math.random() - 0.2,
      },
      ...defaults
    });
  }, 250);
}
